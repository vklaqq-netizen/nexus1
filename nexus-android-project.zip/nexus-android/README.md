# Nexus Android VPN — starter

Тёмный минималистичный Android-проект на Kotlin + Jetpack Compose.

## Возможности стартера
- UI Nexus в тёмной теме
- Локальное сохранение профилей
- Импорт одной/нескольких `vless://` ссылок
- Загрузка HTTPS-подписки
- Запрос разрешения Android VPN и `VpnService` scaffold

## Важно
Это **не готовый рабочий VPN APK**: native Xray/libXray engine ещё нужно подключить. VPNService создаёт TUN, но сам по себе не умеет говорить VLESS + REALITY. См. `ENGINE_INTEGRATION.md`.

## Сборка
1. Установите Android Studio (JDK 17) и Android SDK Platform 35.
2. Откройте эту папку в Android Studio.
3. Дождитесь синхронизации Gradle.
4. Для установки на подключённый телефон: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK будет в `app/build/outputs/apk/debug/app-debug.apk`.

CLI (если установлен Android SDK):
```bash
gradle assembleDebug
```

Откройте `ENGINE_INTEGRATION.md`, прежде чем использовать приложение как VPN.


## Сборка APK прямо через GitHub с телефона

В архив добавлен workflow `.github/workflows/android-apk.yml`.

1. На GitHub в браузере создай репозиторий `nexus-android`.
2. Открой репозиторий → **Add file → Upload files**.
3. Распакуй ZIP на телефоне (например, через Files) и загрузи **содержимое** папки проекта, включая скрытую папку `.github`. Если мобильный интерфейс не позволяет удобно загрузить папку, включи «Версия для ПК» в браузере или загрузи файлы по отдельности.
4. Нажми **Commit changes**.
5. Открой вкладку **Actions**, выбери workflow **Build Nexus APK** и нажми **Run workflow**, если он не запустился сам.
6. Когда запуск завершится зелёной галочкой, открой запуск и скачай артефакт `nexus-debug-apk`. Внутри будет `app-debug.apk`.
7. Открой APK на телефоне и подтверди установку, если Android попросит разрешение.

Workflow собирает debug APK для тестирования. Он не добавляет отсутствующий Xray/libXray движок, поэтому приложение пока не обеспечивает настоящее VPN-соединение.
