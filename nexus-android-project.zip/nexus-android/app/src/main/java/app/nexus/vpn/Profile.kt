package app.nexus.vpn

import android.net.Uri
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Base64

data class Profile(
    val id: String,
    val name: String,
    val uri: String
)

object ProfileParser {
    fun parseInput(raw: String): List<Profile> {
        val text = raw.trim()
        require(text.isNotEmpty()) { "Вставьте ссылку, подписку или список ссылок." }

        val candidates = when {
            text.startsWith("vless://", true) -> listOf(text)
            text.startsWith("https://", true) || text.startsWith("http://", true) ->
                throw IllegalArgumentException("Это ссылка подписки. Нажмите «Импорт подписки», чтобы загрузить её.")
            else -> decodeSubscription(text)
        }

        val links = candidates.flatMap { it.lineSequence().map(String::trim).toList() }
            .filter { it.startsWith("vless://", true) }

        require(links.isNotEmpty()) { "Поддерживается импорт ссылок vless://. В подписке не найдено подходящих узлов." }

        return links.mapIndexed { index, link ->
            val parsed = Uri.parse(link)
            val fragment = parsed.fragment?.let { decode(it) }?.takeIf { it.isNotBlank() }
            val host = parsed.host ?: "VLESS"
            val label = fragment ?: "$host • ${parsed.port.takeIf { it > 0 } ?: 443}"
            Profile(
                id = link.hashCode().toString(),
                name = if (links.size == 1) label else "$label (${index + 1})",
                uri = link
            )
        }.distinctBy { it.uri }
    }

    private fun decodeSubscription(input: String): List<String> {
        val cleaned = input.replace("\r", "").trim()
        val decoded = runCatching {
            String(Base64.getMimeDecoder().decode(cleaned), StandardCharsets.UTF_8)
        }.getOrNull()
        return listOfNotNull(decoded, cleaned)
    }

    private fun decode(value: String): String =
        runCatching { URLDecoder.decode(value, StandardCharsets.UTF_8.name()) }.getOrDefault(value)
}
