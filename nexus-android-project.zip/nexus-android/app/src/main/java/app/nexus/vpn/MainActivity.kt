package app.nexus.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.nexus.vpn.vpn.NexusVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151923)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF8C93A5)

class MainActivity : ComponentActivity() {
    private lateinit var store: ProfileStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProfileStore(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg, surface = Panel, primary = Accent,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) {
                NexusScreen(
                    initial = store.load(),
                    onSave = { store.save(it) },
                    onConnect = { profile ->
                        val permission = VpnService.prepare(this)
                        if (permission != null) {
                            pendingProfile = profile
                            vpnPermission.launch(permission)
                        } else startVpn(profile)
                    },
                    onToast = { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
                )
            }
        }
    }

    private var pendingProfile: Profile? = null
    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) pendingProfile?.let(::startVpn)
        else Toast.makeText(this, "Разрешение VPN не предоставлено", Toast.LENGTH_SHORT).show()
    }

    private fun startVpn(profile: Profile) {
        val intent = Intent(this, NexusVpnService::class.java).apply {
            action = NexusVpnService.ACTION_CONNECT
            putExtra(NexusVpnService.EXTRA_PROFILE_URI, profile.uri)
            putExtra(NexusVpnService.EXTRA_PROFILE_NAME, profile.name)
        }
        startForegroundService(intent)
        Toast.makeText(this, "Профиль передан VPN-службе. Для рабочего туннеля подключите libXray (см. ENGINE_INTEGRATION.md).", Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun NexusScreen(
    initial: List<Profile>,
    onSave: (List<Profile>) -> Unit,
    onConnect: (Profile) -> Unit,
    onToast: (String) -> Unit
) {
    var profiles by remember { mutableStateOf(initial) }
    var selected by remember { mutableStateOf(initial.firstOrNull()?.id) }
    var showImport by remember { mutableStateOf(false) }
    var showSubscription by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var subscriptionUrl by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun add(raw: String) {
        try {
            val newItems = ProfileParser.parseInput(raw)
            profiles = (profiles + newItems).distinctBy { it.uri }
            selected = newItems.firstOrNull()?.id ?: selected
            onSave(profiles)
            input = ""
            showImport = false
            onToast("Импортировано: ${newItems.size}")
        } catch (e: Exception) {
            onToast(e.message ?: "Не удалось импортировать конфигурацию")
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Bg).padding(horizontal = 22.dp, vertical = 18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(42.dp).background(Accent, RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) { Text("N", color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("nexus", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("PRIVATE CONNECTION", fontSize = 10.sp, color = Muted, letterSpacing = 2.sp)
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(9.dp).background(if (profiles.isNotEmpty()) Accent else Muted, CircleShape))
        }

        Spacer(Modifier.height(30.dp))
        Text("Подключение", fontSize = 14.sp, color = Muted)
        Spacer(Modifier.height(10.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Panel)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(112.dp).background(Color(0xFF222039), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(82.dp).background(Accent.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
                        Text("N", color = Accent, fontSize = 42.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(
                    profiles.firstOrNull { it.id == selected }?.name ?: "Сервер не выбран",
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (profiles.isEmpty()) "Добавьте VLESS-профиль" else "VLESS • REALITY / Xray",
                    color = Muted, fontSize = 12.sp
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        val profile = profiles.firstOrNull { it.id == selected }
                        if (profile == null) onToast("Сначала импортируйте профиль VLESS")
                        else onConnect(profile)
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text("Подключить", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                Text("Нужен собственный сервер или подписка", color = Muted, fontSize = 11.sp)
            }
        }

        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Мои серверы", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { showImport = true }) { Text("+ Импорт") }
        }
        Spacer(Modifier.height(4.dp))
        if (profiles.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Пока нет серверов", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("Добавьте vless:// ссылку или подписку", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { showImport = true }) { Text("Добавить сервер") }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(9.dp),
                contentPadding = PaddingValues(bottom = 10.dp)
            ) {
                items(profiles, key = { it.id }) { profile ->
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .background(if (selected == profile.id) Color(0xFF222039) else Panel, RoundedCornerShape(16.dp))
                            .clickable { selected = profile.id }
                            .padding(15.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(38.dp).background(Color(0xFF252A37), CircleShape), contentAlignment = Alignment.Center) {
                            Text("↗", color = Accent, fontSize = 20.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(profile.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text("VLESS • Xray", color = Muted, fontSize = 11.sp)
                        }
                        RadioButton(selected == profile.id, onClick = { selected = profile.id })
                        TextButton(onClick = {
                            profiles = profiles.filterNot { it.id == profile.id }
                            onSave(profiles)
                            if (selected == profile.id) selected = profiles.firstOrNull()?.id
                        }) { Text("Удалить", color = Muted, fontSize = 11.sp) }
                    }
                }
            }
        }

        Text("NEXUS  •  Android VPN starter", color = Color(0xFF52596B), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }

    if (showImport) {
        AlertDialog(
            onDismissRequest = { showImport = false },
            title = { Text("Импорт профиля") },
            text = {
                Column {
                    Text("Вставьте одну или несколько ссылок vless:// или текст подписки.", fontSize = 12.sp, color = Muted)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.fillMaxWidth(), minLines = 4,
                        placeholder = { Text("vless://…") }
                    )
                    TextButton(onClick = { showImport = false; showSubscription = true }) { Text("Загрузить по URL подписки") }
                }
            },
            confirmButton = { TextButton(onClick = { add(input) }) { Text("Импортировать") } },
            dismissButton = { TextButton(onClick = { showImport = false }) { Text("Отмена") } },
            containerColor = Panel
        )
    }

    if (showSubscription) {
        AlertDialog(
            onDismissRequest = { if (!busy) showSubscription = false },
            title = { Text("Подписка") },
            text = {
                Column {
                    Text("Ссылка будет загружена напрямую на устройство. Используйте только доверенные URL.", fontSize = 12.sp, color = Muted)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = subscriptionUrl, onValueChange = { subscriptionUrl = it },
                        modifier = Modifier.fillMaxWidth(), placeholder = { Text("https://example.com/sub.txt") },
                        singleLine = true
                    )
                    if (busy) { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    val url = subscriptionUrl.trim()
                    if (!url.startsWith("https://")) { onToast("Используйте HTTPS-ссылку"); return@TextButton }
                    busy = true
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            runCatching {
                                val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                                    connectTimeout = 12000
                                    readTimeout = 12000
                                    instanceFollowRedirects = false
                                    requestMethod = "GET"
                                }
                                try {
                                    require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
                                    connection.inputStream.bufferedReader().use { it.readText().take(2_000_000) }
                                } finally { connection.disconnect() }
                            }
                        }
                        busy = false
                        result.onSuccess {
                            showSubscription = false
                            subscriptionUrl = ""
                            add(it)
                        }.onFailure { onToast("Не удалось загрузить подписку: ${it.message}") }
                    }
                }) { Text(if (busy) "Загрузка…" else "Загрузить") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { showSubscription = false }) { Text("Отмена") } },
            containerColor = Panel
        )
    }
}
