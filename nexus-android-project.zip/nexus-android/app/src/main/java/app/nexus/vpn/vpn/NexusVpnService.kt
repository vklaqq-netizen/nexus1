package app.nexus.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import app.nexus.vpn.MainActivity

/**
 * Android VPNService lifecycle scaffold.
 *
 * IMPORTANT: This creates the Android TUN interface only. It does NOT route traffic until the
 * official libXray engine bridge is integrated as described in ENGINE_INTEGRATION.md.
 */
class NexusVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val profile = intent.getStringExtra(EXTRA_PROFILE_URI)
                val name = intent.getStringExtra(EXTRA_PROFILE_NAME) ?: "Nexus"
                if (profile.isNullOrBlank()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForeground(NOTIFICATION_ID, notification("Подготовка: $name"))
                try {
                    tun?.close()
                    tun = Builder()
                        .setSession("Nexus")
                        .setMtu(1500)
                        .addAddress("10.77.0.1", 32)
                        .addRoute("0.0.0.0", 0)
                        .addDnsServer("1.1.1.1")
                        .establish()
                    // TODO: hand tun.fileDescriptor + parsed profile to LibXray bridge.
                    // Do not report "connected" until the Xray core actually starts.
                    updateNotification("Туннель создан; движок Xray не подключён")
                } catch (e: Exception) {
                    updateNotification("Ошибка VPN: ${e.message ?: "неизвестная ошибка"}")
                    stopSelf()
                }
            }
            ACTION_DISCONNECT -> stopTunnel()
        }
        return START_NOT_STICKY
    }

    private fun stopTunnel() {
        // TODO: call libXray stopXray before closing TUN.
        runCatching { tun?.close() }
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        runCatching { tun?.close() }
        tun = null
        super.onDestroy()
    }

    private fun notification(message: String): Notification {
        val channelId = "nexus_vpn"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Nexus VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("Nexus VPN")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(message))
    }

    companion object {
        const val ACTION_CONNECT = "app.nexus.vpn.CONNECT"
        const val ACTION_DISCONNECT = "app.nexus.vpn.DISCONNECT"
        const val EXTRA_PROFILE_URI = "profile_uri"
        const val EXTRA_PROFILE_NAME = "profile_name"
        private const val NOTIFICATION_ID = 1001
    }
}
