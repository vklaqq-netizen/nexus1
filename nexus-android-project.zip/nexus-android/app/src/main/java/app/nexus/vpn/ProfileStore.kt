package app.nexus.vpn

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("nexus_profiles", Context.MODE_PRIVATE)

    fun load(): List<Profile> {
        val raw = prefs.getString("items", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val item = array.getJSONObject(i)
                Profile(item.getString("id"), item.getString("name"), item.getString("uri"))
            }
        }.getOrDefault(emptyList())
    }

    fun save(profiles: List<Profile>) {
        val array = JSONArray()
        profiles.forEach {
            array.put(JSONObject().put("id", it.id).put("name", it.name).put("uri", it.uri))
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}
